import LoginForm from "../components/Login/LoginForm"


const Login = () => { 
    return (
        <>
        <h1>login</h1>
        <LoginForm />

        </>
    )
}
export default Login