[ ] Create our own compnents
[ ] Create local state in components
[ ] handle user events (Button, inputs, select)
[ ] Share info between components
[ ] Events in components

