const STORAGE_KEY_USER = 'coffee-user'

export default STORAGE_KEY_USER