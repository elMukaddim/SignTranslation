const ProfileOrderHistoryItem = ({order}) => {
    return <li>{order}</li>
}

export default ProfileOrderHistoryItem